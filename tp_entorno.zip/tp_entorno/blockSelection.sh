#!/bin/bash
cont=1
oracion=''
if [[ $2 == "P" ]]
then
	sed '/^$/d' $1 | sed -n $3p
fi
if [[ $2 == "O" ]]
then
    while read linea; do
        for pal in $linea; do
	    oracion=`echo $oracion $pal`
            if [[ $pal =~ \.$ ]]
            then
		if [[ $cont == $3 ]]
		then
			echo $oracion	
			exit
		fi	
                cont=$((cont+1))
		oracion='' 
            fi 
        done
    done <$1
fi
        
