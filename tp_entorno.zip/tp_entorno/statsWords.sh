#!/bin/bash
t_max=0
t_min=999
pal_max=""
pal_min=""
cont=0
acum=0
result=0
prom=0
while read linea; do
	for pal in $linea; do
		pal_m=`echo $pal  | iconv -f UTF-8 -t ASCII//TRANSLIT | tr -cd 'A-z'`
		t_pal=`echo $pal_m | wc -c`
		t_pal=$((t_pal-1))
		cont=$((cont+1))
		acum=$((acum+t_pal))
		if [[ $t_pal -gt $t_max ]]
		then
			t_max=$t_pal
			pal_max=$pal
		fi
		if [[ $t_pal -lt $t_min ]]
		then
			t_min=$t_pal
			pal_min=$pal
		fi
	done
done < $1 
prom=$((acum/cont))
echo "La palabra mas larga es: $pal_max($t_max letras) La palabra mas corta es: $pal_min($t_min letras) Promedio de longitud:$prom"


