#!/bin/bash
while read linea; do
	for pal in $linea; do
		pal_l=`echo $pal | tr -d '.,'`
		if [[ $pal_l =~ ^[A-Z][a-z]+ ]]
		then	
			echo $pal_l

		fi
	done
done < $1 

