#! /bin/bash
band=0
acum=0
cont=0
cont1=0
    while read linea; do
        for pal in $linea; do
        	cont=$((cont+1))
            	if [[ $pal =~ \.$ ]]
            	then
            		if [[ $band -eq 0 ]] 
            		then
            			min=$cont
            			max=$cont
            			band=1
            		fi
            		if [[ $cont -gt $max ]]
            		then
            			max=$cont
            		fi
            		if [[ $cont -lt $min ]]
            		then
            			min=$cont
            		fi
            		acum=$((acum+cont))     		
            		cont=0
            		cont1=$((cont1+1))
            		           		
            	fi 
        done
    done <$1
    echo la oracion mas larga tiene $max palabras, la mas corta tiene $min y el promedio de palabras en una oracion es $((acum/cont1))
