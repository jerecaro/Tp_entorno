#!/bin/bash
grep -c "^$" $1
