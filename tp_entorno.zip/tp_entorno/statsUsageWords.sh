#!/bin/bash

while read linea; do
	for pal in $linea; do
		pal_l=`echo $pal | iconv -f UTF-8 -t ASCII//TRANSLIT | tr -d '.,'`
		t_pal=${#pal_l}		
		if [[ $t_pal -ge 4 ]]
		then
			
			echo "aparece: "`grep -o -i $pal_l $1 | wc -l` " veces la palabra $pal_l"
		fi
	done
done < $1 

